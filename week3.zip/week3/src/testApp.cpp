#include "testApp.h"

testApp::~testApp()
{
	for (int i = 0; i < boids1.size(); i++)
	{
		delete boids1[i];
	}
    for (int i = 0; i < boids2.size(); i++)
    {
        delete boids2[i];
    }
    for (int i = 0; i < boids3.size(); i++)
    {
        delete boids3[i];
    }
    for (int i = 0; i < boids4.size(); i++)
    {
        delete boids4[i];
    }
    for (int i = 0; i < boids5.size(); i++)
    {
        delete boids5[i];
    }
    for (int i = 0; i < boids6.size(); i++)
    {
        delete boids6[i];
    }
    for (int i = 0; i < boids7.size(); i++)
    {
        delete boids7[i];
    }
}

//--------------------------------------------------------------
void testApp::setup(){
	
	
	int screenW = ofGetScreenWidth();
	int screenH = ofGetScreenHeight();

	ofBackground(0,0,0);
	
	// set up the boids
	for (int i = 0; i < 50; i++)
		boids1.push_back(new Boid());
    for (int i = 0; i < 50; i++)
        boids2.push_back(new Boid());
    for (int i = 0; i < 50; i++)
        boids3.push_back(new Boid());
    for (int i = 0; i < 50; i++)
        boids4.push_back(new Boid());
    for (int i = 0; i < 50; i++)
        boids5.push_back(new Boid());
    for (int i = 0; i < 50; i++)
        boids6.push_back(new Boid());
    for (int i = 0; i < 50; i++)
        boids7.push_back(new Boid());
}


//--------------------------------------------------------------
void testApp::update(){
	
    ofVec3f min(0, 0);
	ofVec3f max(ofGetWidth(), ofGetHeight());
	for (int i = 0; i < boids1.size(); i++)
	{
		boids1[i]->update(boids1, min, max);
	}
    for (int i = 0; i < boids2.size(); i++)
    {
        boids2[i]->update(boids2, min, max);
    }
    for (int i = 0; i < boids3.size(); i++)
    {
        boids3[i]->update(boids3, min, max);
    }
    for (int i = 0; i < boids4.size(); i++)
    {
        boids4[i]->update(boids4, min, max);
    }
    for (int i = 0; i < boids5.size(); i++)
    {
        boids5[i]->update(boids5, min, max);
    }
    for (int i = 0; i < boids6.size(); i++)
    {
        boids6[i]->update(boids6, min, max);
    }
    for (int i = 0; i < boids7.size(); i++)
    {
        boids7[i]->update(boids7, min, max);
    }
}

//--------------------------------------------------------------
void testApp::draw(){

	for (int i = 0; i < boids1.size(); i++)
	{
		boids1[i]->draw1();
	}
    for (int i = 0; i < boids2.size(); i++)
    {
        boids2[i]->draw2();
    }
    for (int i = 0; i < boids3.size(); i++)
    {
        boids3[i]->draw3();
    }
    for (int i = 0; i < boids4.size(); i++)
    {
        boids4[i]->draw4();
    }
    for (int i = 0; i < boids5.size(); i++)
    {
        boids5[i]->draw5();
    }
    for (int i = 0; i < boids6.size(); i++)
    {
        boids6[i]->draw6();
    }
    for (int i = 0; i < boids7.size(); i++)
    {
        boids7[i]->draw7();
    }
}


//--------------------------------------------------------------
void testApp::keyPressed(int key){
 
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){
    
}
